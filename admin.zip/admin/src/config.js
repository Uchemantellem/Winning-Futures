const config = {
    // apiKey: "AIzaSyDrdbVKFZxmLDe8JAlgzyp8AXnTBWDYnkA",
    // authDomain: "react-test-72835.firebaseapp.com",
    // // databaseURL: "https://react-test-72835-default-rtdb.firebaseio.com"
    // // mine
    // databaseURL: "https://winning-futures-default-rtdb.firebaseio.com/"
    apiKey: "AIzaSyCQSHjNKtRqSB_Bks3x0Y8aLP1a-vOYrMY",
    authDomain: "winning-futures.firebaseapp.com",
    projectId: "winning-futures",
    storageBucket: "winning-futures.appspot.com",
    messagingSenderId: "460373487232",
    appId: "1:460373487232:web:dfce8debe3af0315f90065",
    measurementId: "G-GYHB57EH09"
  };
  
  export default config;
  